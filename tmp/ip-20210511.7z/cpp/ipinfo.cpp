#define WINVER 0x0501
#include "IPSearcher.h"
#include <stdio.h>
#include <locale.h>
#include <windows.h>

extern "C" BOOL APIENTRY DllMain(HINSTANCE, DWORD, LPVOID);
extern wchar_t strinvalid[];

int wmain(int argc, wchar_t **argv){
	setlocale(LC_ALL, "");
	AddrW w;
	wchar_t content[ADDR_MAX][ADDR_LEN];
	int i, j, count;

	if (argc < 2){
		wprintf(L" 用法: %s IP地址 [IP地址 ...]\n", argv[0]);
		return 0;
	}

	DllMain(0, DLL_PROCESS_ATTACH, 0);
	for (i=0; i<ADDR_MAX; i++)
		w.c[i] = content[i];
	
	for (i=1; i<argc; i++){
		if (IsIpv6W(argv[i]) || IsIpv4W(argv[i])) {
			count = LookupAddressW(argv[i], &w);
			wprintf(L" IP : %s\n地址:", argv[i]);
			for (j=0; j<count; j++)
				wprintf(L" %s", w.c[j]);
			wprintf(L"\n\n");
		} else {
			// lookup dns records
			wprintf(L" IP : %s\n\n", strinvalid);
		}
	}
	
	DllMain(0, DLL_PROCESS_DETACH, 0);
	
	LocalFree(argv);
	return 0;
}

