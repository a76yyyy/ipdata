#ifndef UTIL_H_
#define UTIL_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
int64_t intn(void *p, int n);
uint64_t uintn(void *p, int n);

#ifdef __cplusplus
}
#endif

#endif
