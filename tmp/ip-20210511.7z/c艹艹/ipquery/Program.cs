﻿using System;
using Newtonsoft.Json;

namespace ipquery
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            AccessFile af = new AccessFile(@"E:\WPF\ipquery\ipquery\ipv6wry.db", "20210510");
            IPv6Object io = af.query("240e:438:426:d60:107f:2b5d:1458:bbc7");
            Console.WriteLine(io.ip_addr);
            Console.WriteLine(JsonConvert.SerializeObject(io));
            Console.ReadLine();
        }
    }
}
