## 说明

+ 把`Program.cs`里面的`E:\CSHARP\ipquery\ipquery\ipv6wry.db`换成对应的地址
+ `io`返回的是一个对象
+ 如有必要，请安装`Newtonsoft.Json`

## 数据返回示例：

```
中国    贵州省  贵阳市  花溪区
{"ip_find":88776,"ip_offset":0,"ip_record_offset":0,"ip_start":"240e:438:400::","ip_end":"240e:438:5ff:ffff::","ip_addr":"中国\t贵州省\t贵阳市\t花溪区","ip_addr_disp":["中国\t贵州省\t贵阳市\t花溪区","中国电信CTNET网络"],"ip_isp":"中国电信CTNET网络","ip_isp_id":0}
```