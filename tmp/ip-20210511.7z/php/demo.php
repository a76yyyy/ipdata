﻿<?php
require("ipdbv4.func.php");
require("ipdbv6.func.php");
error_reporting(E_ERROR | E_WARNING | E_PARSE);

function isipv6($s) {
	return strpos($s, ":") !== false;
}

function err($s) {
	$errstr = <<<EOL
{"code":-1,"data":"$s"}
EOL;
	return $errstr;
}

function query($ip) {
	//$db4 = new ipdbv4("qqwry.db");
	$db6 = new ipdbv6("ipv6wry.db");

	try {
		if ($ip == "") {
			$result = array("disp" => "请输入IP");
		} else if (isipv6($ip)) {
			$result = $db6->query($ip, $db4);
		} else {
			$result = $db4->query($ip);
		}
	} catch (Exception $e) {
		$result = array("disp" => $e->getMessage());
	}
	$i1 = $result["start"];
	$i2 = $result["end"];
	$disp = $result["disp"];
	$o1 = $result["addr"][0];
	$o2 = $result["addr"][1];

	$disp = str_replace("\"", "\\\"", $disp);
	$o1 = str_replace("\"", "\\\"", $o1);
	$o2 = str_replace("\"", "\\\"", $o2);
	$outstr = <<<EOL
{"code":0,"data":{
"myip":"$ip","ip":{"start":"$i1","end":"$i2"},
"location":"$disp","country":"$o1","local":"$o2"
}}
EOL;
	return $outstr;
}

echo query("2406:840::1");

?>
