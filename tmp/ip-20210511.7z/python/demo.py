﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
from ipdbv4 import IPDBv4
from ipdbv6 import IPDBv6

def isipv6(s):
	return s.find(":") != -1

def err(est):
	errstr = u"""{"code":-1,"data":"%s"}""" % est
	return errstr

def query(ip):
	#db4 = IPDBv4(os.path.dirname(__file__) + "/qqwry.db")
	db6 = IPDBv6(os.path.dirname(__file__) + "/ipv6wry.db")

	if isipv6(ip):
		#(i1, i2, oqip, o1, o2) = db6.getIPAddr(ip, db4)
		(i1, i2, oqip, o1, o2) = db6.getIPAddr(ip, None)
	else:
		(i1, i2, oqip, o1, o2) = db4.getIPAddr(ip)

	oqip = oqip.replace("\"", "\\\"");
	o1 = o1.replace("\"", "\\\"");
	o2 = o2.replace("\"", "\\\"");
	outstr = u"""{"code":0,"data":{
"myip":"%s","ip":{"start":"%s","end":"%s"},
"location":"%s","country":"%s","local":"%s"
}}
""" % (ip, i1, i2, oqip, o1, o2)
	return outstr

print(query("2406:840::1"))

